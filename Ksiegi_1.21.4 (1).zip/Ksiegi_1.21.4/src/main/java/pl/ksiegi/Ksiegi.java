package pl.ksiegi;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.*;

import java.util.*;

public class Ksiegi extends JavaPlugin implements Listener, CommandExecutor {

    enum Element {
        OGIEN("§cOgień", new String[]{"Kula ognia", "Pierścień ognia", "Ognisty dash", "Deszcz meteorów", "Ognista tarcza"}, new int[]{6, 10, 8, 25, 30}),
        WODA("§9Woda", new String[]{"Strumień wody", "Fala leczenia", "Zamrożenie", "Tsunami", "Łaska oceanu"}, new int[]{5, 15, 14, 20, 40}),
        WIATR("§bWiatr", new String[]{"Tornado", "Podmuch", "Lot (30s)", "Piorun", "Szybkość wichru"}, new int[]{14, 10, 60, 15, 30}),
        ZIEMIA("§6Ziemia", new String[]{"Ściana ziemi", "Trzęsienie ziemi", "Skóra z kamienia", "Kolce ziemi", "Strażnik ziemi"}, new int[]{12, 12, 25, 10, 45}),
        ODCHLAN("§5Odchłań", new String[]{"Wir otchłani", "Klątwa", "Krok cienia", "Mrok otchłani", "Drenaż duszy"}, new int[]{16, 10, 6, 18, 20});

        final String name; final String[] powers; final int[] cd;
        Element(String n, String[] p, int[] c) { name = n; powers = p; cd = c; }
    }

    static final String MENU = "§8Wybierz swoją księgę";
    NamespacedKey bookKey;
    final Map<UUID, Integer> selected = new HashMap<>();
    final Map<String, Long> cooldowns = new HashMap<>();

    @Override
    public void onEnable() {
        bookKey = new NamespacedKey(this, "ksiega");
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("v").setExecutor(this);
    }

    // ---------- dane gracza ----------
    Element getElement(Player p) {
        String s = getConfig().getString("players." + p.getUniqueId());
        if (s == null) return null;
        try { return Element.valueOf(s); } catch (Exception e) { return null; }
    }

    void setElement(Player p, Element e) {
        getConfig().set("players." + p.getUniqueId(), e == null ? null : e.name());
        saveConfig();
        selected.put(p.getUniqueId(), 0);
    }

    // ---------- menu wyboru ----------
    void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 9, MENU);
        for (Element e : Element.values()) {
            ItemStack it = new ItemStack(Material.ENCHANTED_BOOK);
            ItemMeta m = it.getItemMeta();
            m.setDisplayName("§l" + e.name);
            List<String> lore = new ArrayList<>();
            lore.add("§7Moce:");
            for (String s : e.powers) lore.add("§8- §f" + s);
            m.setLore(lore);
            it.setItemMeta(m);
            inv.setItem(2 + e.ordinal(), it);
        }
        p.openInventory(inv);
    }

    ItemStack makeBook(Element e) {
        ItemStack it = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName("§lKsięga: " + e.name);
        m.setLore(Arrays.asList("§7PPM §8- §fużyj mocy", "§7Shift+PPM §8- §fzmień moc", "§7lub komenda §f/v"));
        m.getPersistentDataContainer().set(bookKey, PersistentDataType.STRING, e.name());
        it.setItemMeta(m);
        return it;
    }

    boolean isBook(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(bookKey, PersistentDataType.STRING);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent ev) {
        Player p = ev.getPlayer();
        if (getElement(p) == null)
            Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) openMenu(p); }, 20);
    }

    @EventHandler
    public void onClick(InventoryClickEvent ev) {
        if (!ev.getView().getTitle().equals(MENU)) return;
        ev.setCancelled(true);
        int slot = ev.getRawSlot() - 2;
        if (slot < 0 || slot >= Element.values().length) return;
        Player p = (Player) ev.getWhoClicked();
        Element e = Element.values()[slot];
        setElement(p, e);
        p.closeInventory();
        p.getInventory().addItem(makeBook(e));
        p.sendMessage("§aWybrałeś księgę: " + e.name + "§a! Użyj §f/v §alub kliknij księgą PPM.");
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent ev) {
        if (!ev.getView().getTitle().equals(MENU)) return;
        Player p = (Player) ev.getPlayer();
        if (getElement(p) == null)
            Bukkit.getScheduler().runTask(this, () -> { if (p.isOnline()) openMenu(p); });
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent ev) {
        Player p = ev.getPlayer();
        Element e = getElement(p);
        if (e != null) Bukkit.getScheduler().runTask(this, () -> p.getInventory().addItem(makeBook(e)));
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent ev) {
        if (ev.getHand() != EquipmentSlot.HAND) return;
        if (ev.getAction() != Action.RIGHT_CLICK_AIR && ev.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isBook(ev.getItem())) return;
        ev.setCancelled(true);
        Player p = ev.getPlayer();
        if (p.isSneaking()) cycle(p); else cast(p);
    }

    // ---------- komenda /v ----------
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) return true;
        if (a.length > 0) {
            switch (a[0].toLowerCase()) {
                case "zmien" -> cycle(p);
                case "ksiega" -> { Element e = getElement(p); if (e != null) p.getInventory().addItem(makeBook(e)); }
                case "reset" -> {
                    if (p.hasPermission("ksiegi.admin")) { setElement(p, null); openMenu(p); }
                }
                default -> p.sendMessage("§e/v §7- użyj mocy, §e/v zmien§7, §e/v ksiega§7, §e/v reset");
            }
            return true;
        }
        cast(p);
        return true;
    }

    void bar(Player p, String msg) {
        p.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(msg));
    }

    void cycle(Player p) {
        Element e = getElement(p);
        if (e == null) { openMenu(p); return; }
        int i = (selected.getOrDefault(p.getUniqueId(), 0) + 1) % e.powers.length;
        selected.put(p.getUniqueId(), i);
        bar(p, e.name + " §7» §f" + e.powers[i]);
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 1, 1.5f);
    }

    // ---------- rzucanie mocy ----------
    void cast(Player p) {
        Element e = getElement(p);
        if (e == null) { openMenu(p); return; }
        int i = selected.getOrDefault(p.getUniqueId(), 0);
        String key = p.getUniqueId() + e.name() + i;
        long now = System.currentTimeMillis();
        long ready = cooldowns.getOrDefault(key, 0L);
        if (now < ready) { bar(p, "§cOdnowienie: " + ((ready - now) / 1000 + 1) + "s"); return; }
        cooldowns.put(key, now + e.cd[i] * 1000L);
        bar(p, e.name + " §7» §f" + e.powers[i]);

        switch (e) {
            case OGIEN -> { switch (i) { case 0 -> fireball(p); case 1 -> fireRing(p); case 2 -> fireDash(p); case 3 -> meteor(p); default -> fireShield(p); } }
            case WODA -> { switch (i) { case 0 -> waterJet(p); case 1 -> healWave(p); case 2 -> freeze(p); case 3 -> tsunami(p); default -> oceanGrace(p); } }
            case WIATR -> { switch (i) { case 0 -> tornado(p); case 1 -> gust(p); case 2 -> fly(p); case 3 -> lightning(p); default -> windSpeed(p); } }
            case ZIEMIA -> { switch (i) { case 0 -> wall(p); case 1 -> quake(p); case 2 -> stoneSkin(p); case 3 -> spikes(p); default -> golem(p); } }
            case ODCHLAN -> { switch (i) { case 0 -> vortex(p); case 1 -> curse(p); case 2 -> shadowStep(p); case 3 -> darkness(p); default -> drain(p); } }
        }
    }

    // ---------- pomocnicze ----------
    LivingEntity targetEntity(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceEntities(eye, eye.getDirection(), range, 0.6,
                en -> en instanceof LivingEntity && !en.equals(p) && !(en instanceof ArmorStand));
        return (r != null && r.getHitEntity() instanceof LivingEntity le) ? le : null;
    }

    Location targetPoint(Player p, int range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), range);
        if (r != null && r.getHitPosition() != null) return r.getHitPosition().toLocation(p.getWorld());
        return eye.add(eye.getDirection().multiply(range));
    }

    List<LivingEntity> nearby(Location l, double r, Player ex) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity en : l.getWorld().getNearbyEntities(l, r, r, r))
            if (en instanceof LivingEntity le && !en.equals(ex) && !(en instanceof ArmorStand)) out.add(le);
        return out;
    }

    void line(Location a, Location b, Particle pt) {
        Vector d = b.toVector().subtract(a.toVector());
        double len = d.length();
        d.normalize().multiply(0.5);
        Location cur = a.clone();
        for (double t = 0; t < len; t += 0.5) {
            a.getWorld().spawnParticle(pt, cur, 2, 0.05, 0.05, 0.05, 0);
            cur.add(d);
        }
    }

    void circle(Location c, double r, Particle pt) {
        for (int k = 0; k < 40; k++) {
            double a = Math.PI * 2 * k / 40;
            c.getWorld().spawnParticle(pt, c.getX() + Math.cos(a) * r, c.getY() + 0.5, c.getZ() + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    // ---------- OGIEŃ ----------
    void fireball(Player p) {
        Fireball fb = p.launchProjectile(Fireball.class, p.getLocation().getDirection().multiply(1.2));
        fb.setYield(2f);
        fb.setIsIncendiary(false);
        p.playSound(p.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1, 1);
    }

    void fireRing(Player p) {
        Location l = p.getLocation();
        circle(l, 5, Particle.FLAME);
        l.getWorld().spawnParticle(Particle.LAVA, l, 30, 3, 0.5, 3, 0);
        for (LivingEntity e : nearby(l, 5, p)) { e.setFireTicks(100); e.damage(4, p); }
        p.playSound(l, Sound.ITEM_FIRECHARGE_USE, 1, 0.8f);
    }

    void fireDash(Player p) {
        p.setVelocity(p.getLocation().getDirection().multiply(1.8));
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (t++ > 10) { cancel(); return; }
                p.getWorld().spawnParticle(Particle.FLAME, p.getLocation(), 15, 0.3, 0.3, 0.3, 0.02);
                for (LivingEntity e : nearby(p.getLocation(), 2, p)) e.setFireTicks(80);
            }
        }.runTaskTimer(this, 0, 1);
        p.playSound(p.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1, 1.5f);
    }

    // ---------- WODA ----------
    void waterJet(Player p) {
        LivingEntity t = targetEntity(p, 25);
        Location start = p.getEyeLocation();
        Location end = t != null ? t.getLocation().add(0, 1, 0) : targetPoint(p, 15);
        line(start, end, Particle.NAUTILUS);
        if (t != null) {
            t.damage(5, p);
            t.setVelocity(p.getLocation().getDirection().multiply(1.2).setY(0.3));
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
        }
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 1, 1);
    }

    void heal(Player t) {
        t.setHealth(Math.min(t.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue(), t.getHealth() + 8));
        t.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
        t.getWorld().spawnParticle(Particle.HEART, t.getLocation().add(0, 1, 0), 8, 0.4, 0.5, 0.4, 0);
    }

    void healWave(Player p) {
        heal(p);
        circle(p.getLocation(), 6, Particle.NAUTILUS);
        for (LivingEntity e : nearby(p.getLocation(), 6, p)) if (e instanceof Player o) heal(o);
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1, 1.5f);
    }

    void freeze(Player p) {
        Location l = p.getLocation();
        circle(l, 6, Particle.SNOWFLAKE);
        l.getWorld().spawnParticle(Particle.SNOWFLAKE, l.clone().add(0, 1, 0), 80, 3, 1, 3, 0.02);
        for (LivingEntity e : nearby(l, 6, p)) {
            e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 3));
            e.setFreezeTicks(200);
            e.damage(2, p);
        }
        p.playSound(l, Sound.BLOCK_GLASS_BREAK, 1, 0.6f);
    }

    // ---------- WIATR ----------
    void tornado(Player p) {
        Location c = targetPoint(p, 25);
        p.playSound(c, Sound.ENTITY_PHANTOM_FLAP, 2, 0.5f);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (t++ > 100) { cancel(); return; }
                World w = c.getWorld();
                for (double y = 0; y < 6; y += 0.4) {
                    double r = 0.5 + y * 0.4, a = t * 0.5 + y * 1.2;
                    w.spawnParticle(Particle.CLOUD, c.getX() + Math.cos(a) * r, c.getY() + y, c.getZ() + Math.sin(a) * r, 1, 0, 0, 0, 0);
                }
                for (LivingEntity e : nearby(c, 4, p)) {
                    Vector d = e.getLocation().toVector().subtract(c.toVector());
                    Vector swirl = new Vector(-d.getZ(), 0, d.getX());
                    if (swirl.lengthSquared() > 0) swirl.normalize().multiply(0.4);
                    Vector in = d.clone().setY(0).multiply(-0.1);
                    e.setVelocity(swirl.add(in).setY(0.5));
                    if (t % 20 == 0) e.damage(2, p);
                }
            }
        }.runTaskTimer(this, 0, 1);
    }

    void gust(Player p) {
        Location l = p.getLocation();
        circle(l, 7, Particle.CLOUD);
        for (LivingEntity e : nearby(l, 7, p)) {
            Vector v = e.getLocation().toVector().subtract(l.toVector()).setY(0);
            if (v.lengthSquared() == 0) v = new Vector(1, 0, 0);
            e.setVelocity(v.normalize().multiply(2).setY(0.5));
        }
        p.playSound(l, Sound.ENTITY_ENDER_DRAGON_FLAP, 1, 1);
    }

    final Map<UUID, BukkitTask> flyTasks = new HashMap<>();

    void stopFly(Player p) {
        BukkitTask t = flyTasks.remove(p.getUniqueId());
        if (t == null) return;
        t.cancel();
        GameMode gm = p.getGameMode();
        if (gm != GameMode.CREATIVE && gm != GameMode.SPECTATOR) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 200, 0));
        bar(p, "§bLot się skończył");
    }

    void fly(Player p) {
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) { bar(p, "§7Już możesz latać"); return; }
        stopFly(p);
        p.setAllowFlight(true);
        p.setFlying(true);
        p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1, 1.3f);
        flyTasks.put(p.getUniqueId(), new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (!p.isOnline() || p.isDead()) { stopFly(p); return; }
                t++;
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 3, 0.3, 0.1, 0.3, 0.01);
                if (t % 20 == 0) bar(p, "§bLot: " + (30 - t / 20) + "s");
                if (t >= 600) stopFly(p);
            }
        }.runTaskTimer(this, 0, 1));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent ev) { stopFly(ev.getPlayer()); }

    void lightning(Player p) {
        Location c = targetPoint(p, 30);
        for (int k = 0; k < 3; k++)
            Bukkit.getScheduler().runTaskLater(this, () -> c.getWorld().strikeLightning(c), k * 8L);
    }

    void windSpeed(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 300, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 300, 2));
        p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1, 0), 40, 0.4, 0.8, 0.4, 0.05);
        p.playSound(p.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 1, 1);
    }

    // ---------- ZIEMIA ----------
    void wall(Player p) {
        Vector d = p.getLocation().getDirection().setY(0).normalize();
        Vector side = new Vector(-d.getZ(), 0, d.getX());
        Location base = p.getLocation().add(d.multiply(3));
        List<Block> placed = new ArrayList<>();
        for (int s = -2; s <= 2; s++)
            for (int h = 0; h < 3; h++) {
                Block b = base.clone().add(side.clone().multiply(s)).add(0, h, 0).getBlock();
                if (b.getType().isAir()) { b.setType(Material.STONE); placed.add(b); }
            }
        p.playSound(p.getLocation(), Sound.BLOCK_STONE_PLACE, 1, 0.7f);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            for (Block b : placed) if (b.getType() == Material.STONE) b.setType(Material.AIR);
        }, 100);
    }

    void quake(Player p) {
        Location l = p.getLocation();
        l.getWorld().spawnParticle(Particle.BLOCK, l, 100, 3, 0.2, 3, Material.DIRT.createBlockData());
        for (LivingEntity e : nearby(l, 6, p)) { e.damage(6, p); e.setVelocity(new Vector(0, 0.8, 0)); }
        p.playSound(l, Sound.ENTITY_GENERIC_EXPLODE, 1, 0.5f);
    }

    void stoneSkin(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 2));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 0));
        p.getWorld().spawnParticle(Particle.BLOCK, p.getLocation().add(0, 1, 0), 40, 0.4, 0.8, 0.4, Material.STONE.createBlockData());
        p.playSound(p.getLocation(), Sound.BLOCK_STONE_BREAK, 1, 0.6f);
    }

    // ---------- ODCHŁAŃ ----------
    void vortex(Player p) {
        Location c = targetPoint(p, 15);
        p.playSound(c, Sound.BLOCK_PORTAL_TRIGGER, 0.6f, 1.5f);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (t++ > 60) { cancel(); return; }
                c.getWorld().spawnParticle(Particle.PORTAL, c, 40, 1.5, 1.5, 1.5, 0.5);
                c.getWorld().spawnParticle(Particle.SOUL, c, 3, 0.5, 0.5, 0.5, 0.02);
                for (LivingEntity e : nearby(c, 10, p)) {
                    Vector v = c.toVector().subtract(e.getLocation().toVector());
                    if (v.lengthSquared() > 0.5) e.setVelocity(v.normalize().multiply(0.5));
                    if (t % 10 == 0) e.damage(2, p);
                }
            }
        }.runTaskTimer(this, 0, 1);
    }

    void curse(Player p) {
        LivingEntity t = targetEntity(p, 25);
        line(p.getEyeLocation(), t != null ? t.getLocation().add(0, 1, 0) : targetPoint(p, 15), Particle.SOUL);
        if (t == null) return;
        t.damage(3, p);
        t.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1));
        t.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0));
        p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.7f, 1.3f);
    }

    void shadowStep(Player p) {
        Vector dir = p.getLocation().getDirection();
        Location last = p.getLocation();
        for (int i = 1; i <= 10; i++) {
            Location t = p.getLocation().add(dir.clone().multiply(i));
            if (!t.getBlock().isPassable() || !t.clone().add(0, 1, 0).getBlock().isPassable()) break;
            last = t;
        }
        p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 60, 0.4, 0.8, 0.4, 0.5);
        p.teleport(last);
        p.getWorld().spawnParticle(Particle.PORTAL, last.clone().add(0, 1, 0), 60, 0.4, 0.8, 0.4, 0.5);
        p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 40, 0));
        p.playSound(last, Sound.ENTITY_ENDERMAN_TELEPORT, 1, 0.8f);
    }

    // ---------- NOWE MOCE ----------
    void meteor(Player p) {
        Location c = targetPoint(p, 30);
        p.playSound(c, Sound.ENTITY_BLAZE_SHOOT, 1, 0.5f);
        new BukkitRunnable() {
            int n = 0;
            public void run() {
                if (n++ >= 7) { cancel(); return; }
                Location from = c.clone().add((Math.random() - 0.5) * 8, 18, (Math.random() - 0.5) * 8);
                c.getWorld().spawn(from, Fireball.class, fb -> {
                    fb.setShooter(p);
                    fb.setDirection(new Vector(0, -1, 0));
                    fb.setYield(2f);
                    fb.setIsIncendiary(false);
                });
            }
        }.runTaskTimer(this, 0, 6);
    }

    void fireShield(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 300, 0));
        p.playSound(p.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1, 0.6f);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (t++ >= 40 || !p.isOnline()) { cancel(); return; }
                circle(p.getLocation(), 2.5, Particle.FLAME);
                for (LivingEntity e : nearby(p.getLocation(), 3, p)) {
                    e.setFireTicks(60);
                    if (t % 2 == 0) e.damage(1.5, p);
                }
            }
        }.runTaskTimer(this, 0, 5);
    }

    void tsunami(Player p) {
        Vector d = p.getLocation().getDirection().setY(0).normalize();
        Location start = p.getLocation().add(d.clone().multiply(1.5));
        Set<UUID> hit = new HashSet<>();
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1, 0.7f);
        new BukkitRunnable() {
            int step = 0;
            public void run() {
                if (step++ > 14) { cancel(); return; }
                Location c = start.clone().add(d.clone().multiply(step));
                Vector side = new Vector(-d.getZ(), 0, d.getX());
                for (int s = -3; s <= 3; s++) {
                    Location l = c.clone().add(side.clone().multiply(s * 0.7));
                    c.getWorld().spawnParticle(Particle.NAUTILUS, l.clone().add(0, 0.8, 0), 4, 0.2, 0.5, 0.2, 0.05);
                    c.getWorld().spawnParticle(Particle.CLOUD, l.clone().add(0, 1.4, 0), 1, 0.1, 0.1, 0.1, 0);
                }
                for (LivingEntity e : nearby(c, 2.8, p))
                    if (hit.add(e.getUniqueId())) {
                        e.damage(4, p);
                        e.setVelocity(d.clone().multiply(1.6).setY(0.5));
                    }
            }
        }.runTaskTimer(this, 0, 1);
    }

    void oceanGrace(Player p) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 600, 0));
        p.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, 600, 0));
        p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 400, 1));
        p.getWorld().spawnParticle(Particle.NAUTILUS, p.getLocation().add(0, 1, 0), 60, 0.5, 0.8, 0.5, 0.3);
        p.playSound(p.getLocation(), Sound.AMBIENT_UNDERWATER_ENTER, 1, 1);
    }

    void spikes(Player p) {
        Vector d = p.getLocation().getDirection().setY(0).normalize();
        Location start = p.getLocation();
        Set<UUID> hit = new HashSet<>();
        new BukkitRunnable() {
            int step = 0;
            public void run() {
                if (step++ > 12) { cancel(); return; }
                Location c = start.clone().add(d.clone().multiply(step));
                c.getWorld().spawnParticle(Particle.BLOCK, c, 25, 0.3, 0.6, 0.3, Material.DIRT.createBlockData());
                c.getWorld().playSound(c, Sound.BLOCK_GRAVEL_BREAK, 1, 0.6f);
                for (LivingEntity e : nearby(c, 1.6, p))
                    if (hit.add(e.getUniqueId())) {
                        e.damage(5, p);
                        e.setVelocity(new Vector(0, 1.0, 0));
                    }
            }
        }.runTaskTimer(this, 0, 2);
    }

    void golem(Player p) {
        Location l = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(2));
        IronGolem g = p.getWorld().spawn(l, IronGolem.class, gg -> {
            gg.setPlayerCreated(true);
            gg.setCustomName("§6Strażnik " + p.getName());
            gg.setCustomNameVisible(true);
        });
        p.playSound(l, Sound.BLOCK_ANVIL_LAND, 1, 0.5f);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (g.isValid()) {
                g.getWorld().spawnParticle(Particle.BLOCK, g.getLocation().add(0, 1, 0), 40, 0.5, 1, 0.5, Material.STONE.createBlockData());
                g.remove();
            }
        }, 600);
    }

    void darkness(Player p) {
        Location l = p.getLocation();
        circle(l, 8, Particle.SOUL);
        l.getWorld().spawnParticle(Particle.PORTAL, l.clone().add(0, 1, 0), 120, 4, 1, 4, 0.5);
        for (LivingEntity e : nearby(l, 8, p)) {
            e.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 120, 0));
            e.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0));
            e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 120, 1));
        }
        p.playSound(l, Sound.ENTITY_WARDEN_HEARTBEAT, 1, 0.7f);
    }

    void drain(Player p) {
        Location l = p.getLocation();
        double max = p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
        double gain = 0;
        for (LivingEntity e : nearby(l, 6, p)) {
            e.damage(3, p);
            line(e.getLocation().add(0, 1, 0), p.getLocation().add(0, 1, 0), Particle.SOUL);
            gain += 2;
        }
        p.setHealth(Math.min(max, p.getHealth() + gain));
        p.playSound(l, Sound.ENTITY_WITHER_AMBIENT, 0.7f, 1.5f);
    }
}
